import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
config = json.loads((root / "plugin.json").read_text())
assert config["entryPoint"] == "YouTubeDirectAudioPlugin"
assert "localstorage" in config["apis"]
assert "authentication" in config["abilities"]

plugin = (root / "src/plugin.ht").read_text()
audio = (root / "src/segments/audio_source.ht").read_text()
auth = (root / "src/segments/auth.ht").read_text()
sha1 = (root / "src/segments/sha1.ht").read_text()
core = (root / "src/segments/core.ht").read_text()

assert "export { YouTubeDirectAudioPlugin }" in plugin
assert "AudioSourceEndpoint(auth)" in plugin
assert "construct (authEndpoint)" in audio
assert "auth.requestHeaders()" in audio
assert "https://www.youtube.com/youtubei/v1/player" in audio
assert "LocalStorage.setString(\"yt_cookie_auth\"" in auth
assert "LocalStorage.getString(\"yt_cookie_auth\"" in auth
assert "LocalStorage.remove(\"yt_cookie_auth\")" in auth
assert "SAPISIDHASH" in auth and "sha1Hex" in auth
assert "export { CorePlugin }" in core
assert "export { sha1Hex }" in sha1
print("Static plugin contract checks passed. Hetu compilation is run by `make compile`.")
